using UnityEngine;
using System.Collections;

namespace sharePlus.XCodeEditor
{
	public class XCSourceFile : System.IDisposable
	{
		public void Dispose()
		{
			
		}
	}
}