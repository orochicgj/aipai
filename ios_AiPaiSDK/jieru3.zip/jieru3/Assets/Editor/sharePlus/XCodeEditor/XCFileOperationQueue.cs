using UnityEngine;
using System.Collections;

namespace sharePlus.XCodeEditor
{
	public class XCFileOperationQueue : System.IDisposable
	{
		public void Dispose()
		{
			
		}
	}
}